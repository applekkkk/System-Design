<template>
  <div>
    <el-container>
      <el-header>
        <h2>关于我们</h2>
      </el-header>
      <el-main>
        <p>这里是关于我们的介绍...</p>
      </el-main>
    </el-container>
  </div>
</template>

<script>
export default {
  name: "AboutPage" // 修改为多词名称
};
</script>

<style scoped>
/* 关于页面样式 */
</style>
